import Vue from 'vue';
import ToggleButton from 'vue-js-toggle-button'

Vue.use(ToggleButton);
